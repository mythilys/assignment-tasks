from django.contrib import admin
from .models import chocolate

admin.site.register(chocolate)
