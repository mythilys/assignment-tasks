from django.apps import AppConfig


class ChocolateConfig(AppConfig):
    name = 'chocolate'
