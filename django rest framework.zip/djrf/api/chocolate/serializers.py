from rest_framework import serializers
from .models import chocolate

class ChocolateSerializer(serializers.ModelSerializer):
    class Meta:
        model= chocolate
        fields=('id','name','production')