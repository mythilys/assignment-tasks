from django.shortcuts import render
from rest_framework import viewsets
from .models import chocolate
from .serializers import ChocolateSerializer

class ChocolateView(viewsets.ModelViewSet):
    queryset= chocolate.objects.all()
    serializer_class= ChocolateSerializer
